from pyModbusTCP.client import ModbusClient
client = ModbusClient(host="192.168.0.85", port=502, auto_open=True, debug=False)
while(True):
    inputs=client.read_discrete_inputs(0,4)
    endschalter_oben  = inputs[0]
    endschalter_unten = inputs[1]
    taster_runter     = inputs[2]
    taster_hoch       = inputs[3]
    motor_hoch        = 0
    motor_runter      = 1
    if(endschalter_oben):
        client.write_single_coil(motor_hoch,False)
        print("Tor offen")
    if(endschalter_unten):
        client.write_single_coil(motor_runter,False)
        print("Tor geschlossen")
    if (taster_hoch and not endschalter_oben):
        client.write_single_coil(motor_hoch,True)
    if (taster_runter and not endschalter_unten):
        client.write_single_coil(motor_runter,True)




